<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listagem Estoque</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
 <style>
        th, td {
            padding: 4px 12px;
        }
    </style>
</head>
<body >
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup" style="justify-content: space-between;">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?php echo e(route('livros.index')); ?>">Livros</a>
      <a class="nav-item nav-link" href="<?php echo e(route('funcionarios.index')); ?>">Funcionários</a>
      <a class="nav-item nav-link" href="<?php echo e(route('vendas.index')); ?>">Vendas </a>
      <a class="nav-item nav-link active" href="<?php echo e(route('estoque.index')); ?>">Estoque </a>
        <a class="nav-item nav-link" href="<?php echo e(route('fornecedores.index')); ?>">Fornecedores </a>    
    </div>
    <?php
        $splittedArray = explode("/", $_SERVER['REQUEST_URI']);
        $splittedArray = array_slice($splittedArray,0, 3);
        $url = join("/", $splittedArray);
                                    
                          
    ?>
    <a class="nav-item nav-link active" href="<?php echo e(route('logout')); ?>" style="color: rgba(255,255,255,.5); display: flex; align-items:center;gap: 8px;">LOGOUT<img src="<?php echo e($url); ?>/storage/sign-out.svg" /></a>
 
    </div>
  </div>
</nav>
<div  class="container" style="padding: 20px 0">
        <h2>Listagem de Estoque</h2>
    <form action="<?php echo e(route('estoque.search')); ?>" method="post" class="d-flex p-2" style="gap: 6px">
        <?php echo csrf_field(); ?>
        <select name="tipo" class="form-control" style="width: 180px">
            <option value="quantidade">Quantidade</option>
            <option value="motivo">Motivo</option>
        </select>
        <input type="text" name="valor" placeholder="Pesquisar" class="form-control" style="height: 38px; width: 240px">
        <button type="submit" class="btn btn-primary" style="height: 38px">Buscar</button>
        <a href="<?php echo e(route('estoque.create')); ?>" class="btn btn-success" style="height: 38px">Cadastrar</a>
        <a class="btn btn-dark"
                    href="<?php echo e(route('estoque.chart')); ?>" style="height: 38px" target="_blank">Gráfico</a>
        <a class="btn btn-dark"
                    href="<?php echo e(route('estoque.report')); ?>" style="height: 38px" target="_blank">Relatório</a><br><br>
    </form>
    <table class="table">
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Livro</th>
          <th scope="col">Fornecedor</th>
          <th scope="col">Quantidade</th>
          <th scope="col">Motivo</th>
          
          
          <th scope="col" style="width: 160px"></th>
        </tr>
        <?php $__currentLoopData = $estoque; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->livro->nome ?? ""); ?></td>
                <td><?php echo e($item->fornecedor->nome ?? ""); ?></td>
                <td><?php echo e($item->quantidade); ?></td>
                <td><?php echo e($item->motivo); ?></td>                
                
                <td class="d-flex p-2" style="gap: 6px; width: 160px">
                <a href="<?php echo e(route('estoque.edit', $item->id)); ?>" class="btn btn-info">Editar</a>
                <a href="<?php echo e(route('estoque.destroy', $item->id)); ?>" onclick="return confirm('Deseja Excluir?')" class="btn btn-danger">Excluir</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
      </div>
</body>
</html>
<?php /**PATH C:\laragon\www\juliusAmazingLovingGodMajesticWonderfulHandsome\resources\views/estoque/list.blade.php ENDPATH**/ ?>