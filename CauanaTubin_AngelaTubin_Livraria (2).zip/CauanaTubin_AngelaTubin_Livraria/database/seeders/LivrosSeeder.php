<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class LivrosSeeder extends Seeder
{
    public function run(): void
    {
        $fake = Faker::create("pt_BR");
        foreach(\range(1,5) as $index){
            DB::table('livros')->insert([
                'nome' => $fake->word,
                'editora' => $fake->word,
                'ano_publi' => $fake->year($max = 'now'),
                'autor' => $fake->name,
                'preco' => $fake->randomFloat($nbMaxDecimals = 5, $min = 0, $max = 500),
                'imagem' => $fake->image
            ]);
        }
    }
}

