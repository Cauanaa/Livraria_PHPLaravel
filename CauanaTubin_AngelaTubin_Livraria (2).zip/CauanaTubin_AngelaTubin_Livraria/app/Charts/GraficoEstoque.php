<?php

namespace App\Charts;

use ArielMejiaDev\LarapexCharts\LarapexChart;

class GraficoEstoque
{
    protected $chart;

    public function __construct(LarapexChart $chart)
    {
        $this->chart = $chart;
    }

    public function build(): \ArielMejiaDev\LarapexCharts\PieChart
    {

        $data = \App\Models\Estoque::all();
        return $this->chart->pieChart()
            ->setTitle('Estoque')
            ->addData($data->pluck('quantidade')->toArray())
            ->setLabels($data->pluck('livro')->pluck('nome')->toArray());
    }
}

