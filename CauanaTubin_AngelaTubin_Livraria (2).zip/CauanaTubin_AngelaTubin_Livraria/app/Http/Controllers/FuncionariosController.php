<?php

namespace App\Http\Controllers;

use App\Models\Funcionarios;
use Illuminate\Http\Request;
use PDF;

class FuncionariosController extends Controller
{
    /**
     * Carrega a listagem de dados
     */
    public function index()
    {
        $funcionarios = Funcionarios::all();

        return view('funcionarios.list')->with(['funcionarios'=> $funcionarios]);
    }

    /**
     * Carrega o formulário
     */
    public function create()
    {

        return view('funcionarios.form');
    }

    /**
     * Salva os dados do formulário
     */
    public function store(Request $request)
    {

        $request->validate([
            'nome'=>'max:100|required',
            'cpf'=>'size:11|required',
            'email'=>'required|email'
        ],[
            'required'=>"O campo é obrigatório!",
            'max'=>" Só é permitido 100 caracteres no :attribute!",
            'size'=>"Só é permitido 11 caracteres no :attribute!",
            'email'=>" O :attribute não apresenta formato de email!",
        ]);

        $dados = ['nome'=> $request->nome,
            'data_admissao'=> $request->data_admissao,
            'cpf'=> $request->cpf,
            'email'=> $request->email,
        ];


        Funcionarios::create($dados); //ou  $request->all()

        return redirect('funcionarios')->with('success', "Cadastrado com sucesso!");
    }

    /**
     * Carrega apenas 1 registro da tabela
     */
    public function show(Funcionarios $aluno)
    {
        //
    }

    /**
     * Carrega o formulário para edição
     */
    public function edit($id)
    {
        $funcionarios = Funcionarios::find($id);


        return view('funcionarios.form')->with(['funcionarios'=>$funcionarios]);
    }

    /**
     * Atualiza os dados do formulário
     */
    public function update(Request $request, Funcionarios $funcionario)
    {
       
        $request->validate([
            'nome'=>'max:100|required',
            'cpf'=>'size:11|required',
            'email'=>'required|email'
        ],[
            'required'=>"O campo é obrigatório!",
            'max'=>" Só é permitido 100 caracteres no :attribute!",
            'size'=>"Só é permitido 11 caracteres no :attribute!",
            'email'=>" O :attribute não apresenta formato de email!",
        ]);

        $dados = ['nome'=> $request->nome,
            'data_admissao'=> $request->data_admissao,
            'cpf'=> $request->cpf,
            'email'=> $request->email,
        ];
        
        Funcionarios::updateOrCreate(['id'=>$request->id],$dados);

        return redirect('funcionarios')->with('success', "Atualizado com sucesso!");
    }

    /**
     * Remove o registro do banco de dados
     */
    public function destroy($id)
    {
        $funcionario = Funcionarios::find($id);

        $funcionario->delete();

        return redirect('funcionarios')->with('success', "Removido com sucesso!");
    }
    public function search(Request $request)
    {
        if(!empty($request->valor)){
            $funcionarios = Funcionarios::where($request->tipo, 'like', "%". $request->valor."%")->get();
        } else{
            $funcionarios = Funcionarios::all();
        }
        return view('funcionarios.list')->with(['funcionarios'=> $funcionarios]);
    }

    public function report(){
        //select * from aluno order by nome
        $funcionarios = Funcionarios::orderBy('id')->get();
    
        $data = [
            'title'=>"Relatório Funcionários",
            'funcionarios'=> $funcionarios
        ];
    
        $pdf = PDF::loadView('funcionarios.report',$data);
        //$pdf->setPaper('a4', 'landscape');
       // dd($pdf);
    
        return $pdf->download("relatório_funcionários.pdf");
    }
}
