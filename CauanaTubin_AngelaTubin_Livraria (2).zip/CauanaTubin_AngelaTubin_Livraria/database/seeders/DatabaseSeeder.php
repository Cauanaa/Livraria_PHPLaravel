<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Database\Seeders\LivrosSeeder;
use Database\Seeders\FuncionariosSeeder;
use Database\Seeders\VendasSeeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call(LivrosSeeder::class);
        $this->call(FuncionariosSeeder::class);
        $this->call(VendasSeeder::class);
        $this->call(FornecedoresSeeder::class);
        $this->call(EstoqueSeeder::class);
    }
}