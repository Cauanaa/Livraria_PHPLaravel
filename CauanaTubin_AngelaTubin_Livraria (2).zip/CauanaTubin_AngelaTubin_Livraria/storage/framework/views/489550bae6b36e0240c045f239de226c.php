<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Estoque</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        input, select {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup" style="justify-content: space-between;">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?php echo e(route('livros.index')); ?>">Livros</a>
      <a class="nav-item nav-link" href="<?php echo e(route('funcionarios.index')); ?>">Funcionários</a>
      <a class="nav-item nav-link" href="<?php echo e(route('vendas.index')); ?>">Vendas </a>
      <a class="nav-item nav-link active" href="<?php echo e(route('estoque.index')); ?>">Estoque </a>
        <a class="nav-item nav-link" href="<?php echo e(route('fornecedores.index')); ?>">Fornecedores </a>    
    </div>

    <a class="nav-item nav-link active" href="<?php echo e(route('logout')); ?>" style="color: rgba(255,255,255,.5); display: flex; align-items:center;gap: 8px;">LOGOUT<img src="/storage/sign-out.svg" /></a>
 
    </div>
  </div>
</nav>
<div class="container" style="padding: 20px 0">
    <h2>Formulário de Estoque</h2>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php
        // dd($estoque);
        // $route('estoque.store');
        if (!empty($estoque->id)) {
            $route = route('estoque.update', $estoque->id);
        }
        else {
            $route = route('estoque.store');
        }
    ?>
   
    <form action="<?php echo e($route); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(!empty($estoque->id)): ?>
             <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        
        <input type="hidden" name="id" value="
            <?php if(!empty($estoque->id)): ?>
                    <?php echo e($estoque->id); ?>

                <?php elseif(!empty(old('id'))): ?>
                    <?php echo e(old('id')); ?>

                <?php else: ?>
                    <?php echo e(''); ?>

            <?php endif; ?>"> <label for="">Livro</label>
        <select class="form-control" required name="livros_id">
            <?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty($estoque->livros_id) and $estoque->livros_id == $item->id): ?>
                    <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->nome); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nome); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </select>
            <label for="">Fornecedor</label>
        <select class="form-control" required name="fornecedores_id">
            <?php $__currentLoopData = $fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty($estoque->fornecedores_id) and $estoque->fornecedores_id == $item->id): ?>
                    <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->nome); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nome); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="">Quantidade</label>
        <input class="form-control" type="number" required name="quantidade" value="<?php if(!empty($estoque->quantidade)): ?><?php echo e($estoque->quantidade); ?><?php elseif(!empty(old('quantidade'))): ?><?php echo e(old('quantidade')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        <label for="">Motivo</label>
        <input class="form-control" type="text" required name="motivo" value="<?php if(!empty($estoque->motivo)): ?><?php echo e($estoque->motivo); ?><?php elseif(!empty(old('motivo'))): ?><?php echo e(old('motivo')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        
        
        <button type="submit" class="btn btn-success" style="height: 38px">Salvar</button>
        <a href="<?php echo e(route('estoque.index')); ?>" class="btn btn-primary" style="height: 38px">Voltar</a>
    </form>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\Livraria\resources\views/estoque/form.blade.php ENDPATH**/ ?>