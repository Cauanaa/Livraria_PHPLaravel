<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Estoque extends Model
{
    use HasFactory;
    protected $table = "estoque";

    protected $fillable = ['livros_id',
        'fornecedores_id',
        'quantidade',
        'motivo'
    ];

    protected $casts = [
        'quantidade'=>"integer",
        'fornecedores_id'=>"integer",
        'livros_id'=>"integer",
    ];

    public function fornecedor(){
        return $this->belongsTo(Fornecedores::class,
            'fornecedores_id','id');
    }

    public function livro(){
        return $this->belongsTo(Livros::class,
            'livros_id','id');
    }
}
