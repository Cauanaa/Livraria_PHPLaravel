<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Fornecedores</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        input, select {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup" style="justify-content: space-between;">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?php echo e(route('livros.index')); ?>">Livros</a>
      <a class="nav-item nav-link" href="<?php echo e(route('funcionarios.index')); ?>">Funcionários</a>
      <a class="nav-item nav-link" href="<?php echo e(route('vendas.index')); ?>">Vendas </a>
      <a class="nav-item nav-link" href="<?php echo e(route('estoque.index')); ?>">Estoque </a>
      <a class="nav-item nav-link active" href="<?php echo e(route('fornecedores.index')); ?>">Fornecedores </a>    
    </div>
    <?php
        $splittedArray = explode("/", $_SERVER['REQUEST_URI']);
        $splittedArray = array_slice($splittedArray,0, 3);
        $url = join("/", $splittedArray);
                                    
    ?>
    <a class="nav-item nav-link active" href="<?php echo e(route('logout')); ?>" style="color: rgba(255,255,255,.5); display: flex; align-items:center;gap: 8px;">LOGOUT<img src="<?php echo e($url); ?>/storage/sign-out.svg" /></a>
  </div>
</nav>
<div class="container" style="padding: 20px 0">
    <h2>Formulário de Fornecedores</h2>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php
        if (!empty($fornecedores->id)) {
            $route = route('fornecedores.update', $fornecedores->id);
        }
        else {
            $route = route('fornecedores.store');
        }
    ?>
    <form action="<?php echo e($route); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(!empty($fornecedores->id)): ?>
             <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <input type="hidden" name="id" value="
            <?php if(!empty($fornecedores->id)): ?>
                    <?php echo e($fornecedores->id); ?>

                <?php elseif(!empty(old('id'))): ?>
                    <?php echo e(old('id')); ?>

                <?php else: ?>
                    <?php echo e(''); ?>

            <?php endif; ?>">
        <label for="">Nome</label>
        <input class="form-control" type="text" required name="nome" value="<?php if(!empty($fornecedores->nome)): ?><?php echo e($fornecedores->nome); ?><?php elseif(!empty(old('nome'))): ?><?php echo e(old('nome')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        <label for="">CNPJ</label>
        <input class="form-control" type="text" required name="cnpj" value="<?php if(!empty($fornecedores->cnpj)): ?><?php echo e($fornecedores->cnpj); ?><?php elseif(!empty(old('cnpj'))): ?><?php echo e(old('cnpj')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        <label for="">Endereço</label>
        <input class="form-control" type="text" required name="endereco" value="<?php if(!empty($fornecedores->endereco)): ?><?php echo e($fornecedores->endereco); ?><?php elseif(!empty(old('endereco'))): ?><?php echo e(old('endereco')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
                <?php
                $nome_imagem = !empty($fornecedores->imagem) ? $fornecedores->imagem : 'sem_imagem.jpg';
                                ?>
                <div>
                    <img class="h-40 w-40 object-cover rounded-full" src="<?php echo e($url); ?>/storage/<?php echo e($nome_imagem); ?>" width="300px"
                        alt="imagem">
                    <br>
                    <input
                        class="block w-full text-sm text-slate-500
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-full file:border-0
                                file:text-sm file:font-semibold
                                file:bg-green-50 file:text-green-700
                                hover:file:bg-green-100"
                        type="file" name="imagem"><br>
                </div>
        <button type="submit" class="btn btn-success" style="height: 38px">Salvar</button>
        <a href="<?php echo e(route('fornecedores.index')); ?>" class="btn btn-primary" style="height: 38px">Voltar</a>
    </form>
    </div>
    </div>
    <body>
    <?php /**PATH C:\laragon\www\juliusAmazingLovingGodMajesticWonderfulHandsome\resources\views/fornecedores/form.blade.php ENDPATH**/ ?>