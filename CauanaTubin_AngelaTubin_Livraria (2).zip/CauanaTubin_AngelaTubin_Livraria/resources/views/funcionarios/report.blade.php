<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Relatório Funcionários</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-2">
        <h2 class="text-center mb-2">{{$title}}</h2>
        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-success">
                    <th scope="col">ID</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Data de Admissão</th>
                    <th scope="col">CPF</th>
                    <th scope="col">Email</th>
                </tr>
            </thead>
            <tbody>
                @foreach($funcionarios ?? '' as $item)
                @php
                    $date = date_create($item->data_admissao);
                    $formattedDate = date_format($date,"d/m/Y");
                @endphp
                <tr>
                    <td>{{$item->id}}</td>
                    <td>{{$item->nome}}</td>
                    <td>{{$formattedDate}}</td>
                    <td>{{$item->cpf}}</td>
                    <td>{{$item->email}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>
</html>
