<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listagem Fornecedores</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
 <style>
        th, td {
            padding: 4px 12px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?php echo e(route('livros.index')); ?>">Livros</a>
      <a class="nav-item nav-link active" href="<?php echo e(route('funcionarios.index')); ?>">Funcionários</a>
      <a class="nav-item nav-link" href="<?php echo e(route('vendas.index')); ?>">Vendas </a>
    </div>
  </div>
</nav>
<div  class="container" style="padding: 20px 0">
    <h2>Listagem de Fornecedores</h2>
    <form action="<?php echo e(route('fornecedores.search')); ?>" method="post" class="d-flex p-2" style="gap: 6px">
        <?php echo csrf_field(); ?>
        <select name="tipo" class="form-control" style="width: 180px">
            <option value="nome">Nome</option>
            <option value="imagem">Logo</option>
            <option value="cnpj">CNPJ</option>
            <option value="endereco">Endereço</option>
        </select>
        <input type="text" name="valor" placeholder="Pesquisar" class="form-control" style="height: 38px; width: 240px">
        <button type="submit" class="btn btn-primary" style="height: 38px">Buscar</button>
        <a href="<?php echo e(route('fornecedores.create')); ?>" class="btn btn-success" style="height: 38px">Cadastrar</a><br><br>
    </form>
    <table class="table">
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Logo</th>
          <th scope="col">Nome</th>
          <th scope="col">CNPJ</th>
          <th scope="col">Endereço</th>
        </tr>
        <?php $__currentLoopData = $fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
                    $nome_imagem = !empty($item->imagem) ? $item->imagem : 'sem_imagem.jpg';
                ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td class="h-32 w-32 object-cover rounded-full"><img src="/storage/<?php echo e($nome_imagem); ?>" width="100px" alt="imagem"></td>
                <td><?php echo e($item->nome); ?></td>
                <td><?php echo e($item->cnpj); ?></td>
                <td><?php echo e($item->endereco); ?></td>
                <td class="d-flex p-2" style="gap: 6px; width: 160px"><a href="<?php echo e(route('fornecedores.edit', $item->id)); ?>" class="btn btn-info">Editar</a><a href="<?php echo e(route('fornecedores.destroy', $item->id)); ?>" onclick="return confirm('Deseja Excluir?')"  class="btn btn-danger">Excluir</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
</body>
</html>
<?php /**PATH C:\laragon\www\CauanaTubin_AngelaTubin\resources\views/fornecedores/list.blade.php ENDPATH**/ ?>