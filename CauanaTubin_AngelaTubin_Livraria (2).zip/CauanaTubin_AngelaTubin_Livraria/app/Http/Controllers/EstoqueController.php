<?php

namespace App\Http\Controllers;

use App\Models\Fornecedores;
use App\Models\Livros;
use App\Models\Estoque;
use Illuminate\Http\Request;
use App\Charts\GraficoEstoque;
use PDF;

class EstoqueController extends Controller
{
    /**
     * Carrega a listagem de dados
     */
    public function index()
    {
        $estoque = Estoque::all();

        return view('estoque.list')->with(['estoque'=> $estoque]);
    }

    /**
     * Carrega o formulário
     */
    public function create()
    {
        $fornecedores = Fornecedores::orderBy('nome')->get();
        $livros = Livros::orderBy('nome')->get();

        return view('estoque.form')->with(['fornecedores'=>$fornecedores,'livros'=>$livros ]);
    }

    /**
     * Salva os dados do formulário
     */
    public function store(Request $request)
    {

        $request->validate([
            'motivo'=>'max:100|required',
            'quantidade'=>'required'
        ],[
            'required'=>"O campo é obrigatório!",
            'max'=>" Só é permitido 100 caracteres no :attribute !",
        ]);

        $dados = ['motivo'=> $request->motivo,
        'livros_id'=> $request->livros_id,
            'fornecedores_id'=> $request->fornecedores_id,
            'quantidade'=> $request->quantidade,
        ];


        Estoque::create($dados); //ou  $request->all()

        return redirect('estoque')->with('success', "Cadastrado com sucesso!");
    }

    /**
     * Carrega apenas 1 registro da tabela
     */
    public function show(Estoque $aluno)
    {
        //
    }

    /**
     * Carrega o formulário para edição
     */
    public function edit($id)
    {
        $estoque = Estoque::find($id);

        $fornecedores = Fornecedores::orderBy('nome')->get();
        $livros = Livros::orderBy('nome')->get();

        return view('estoque.form')->with(['estoque'=>$estoque, 'fornecedores'=>$fornecedores, 'livros'=>$livros]);
    }

    /**
     * Atualiza os dados do formulário
     */
    public function update(Request $request, Estoque $venda)
    {
       
        $request->validate([
            'motivo'=>'max:100|required',
            'quantidade'=>'required'
        ],[
            'required'=>"O campo é obrigatório!",
            'max'=>" Só é permitido 100 caracteres no :attribute !",
        ]);

        $dados = ['motivo'=> $request->motivo,
            'livros_id'=> $request->livros_id,
            'fornecedores_id'=> $request->fornecedores_id,
            'quantidade'=> $request->quantidade,
        ];

        Estoque::updateOrCreate(['id'=>$request->id],$dados);

        return redirect('estoque')->with('success', "Atualizado com sucesso!");
    }

    /**
     * Remove o registro do banco de dados
     */
    public function destroy($id)
    {
        $venda = Estoque::find($id);

        $venda->delete();

        return redirect('estoque')->with('success', "Removido com sucesso!");
    }
    public function search(Request $request)
    {
        if(!empty($request->valor)){
            $estoque = Estoque::where($request->tipo, 'like', "%". $request->valor."%")->get();
        } else{
            $estoque = Estoque::all();
        }
        return view('estoque.list')->with(['estoque'=> $estoque]);
    }

    public function chart(GraficoEstoque $estoque){

        return view('estoque.chart')->with(['estoque'=>  $estoque->build()
    ]);
}
public function report(){
    //select * from aluno order by nome
    $estoque = Estoque::orderBy('id')->get();

    $data = [
        'title'=>"Relatório Estoque",
        'estoque'=> $estoque
    ];

    $pdf = PDF::loadView('estoque.report',$data);
    //$pdf->setPaper('a4', 'landscape');
   // dd($pdf);

    return $pdf->download("relatório_estoque.pdf");
}
}