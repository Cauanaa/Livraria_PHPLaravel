<?php

namespace App\Charts;

use ArielMejiaDev\LarapexCharts\LarapexChart;

class GraficoVendas
{
    protected $chart;

    public function __construct(LarapexChart $chart)
    {
        $this->chart = $chart;
    }

    public function myfunction($v)
    {
      return('teste'.$v.'.');
    }


    public function build(): \ArielMejiaDev\LarapexCharts\LineChart
    {
        $data = \App\Models\Vendas::all();
        $dates = array_unique($data->pluck('data')->toArray());
        sort($dates);
        $salesByDate = [];

        foreach ($dates as $item) {
            array_push($salesByDate, 0);
        }

        foreach ($data as $item) {
            for ($i = 0; $i < sizeof($dates); $i++) {
                if($dates[$i] == $item->data) {
                    $salesByDate[$i] += 1;
                    break;
                }
            }
        }

        for ($i = 0; $i < sizeof($dates); $i++) {
            $date=date_create($dates[$i]);
            $dates[$i] = date_format($date,"d/m/Y");
        }
        
        return $this->chart->lineChart()
            ->setTitle("Vendas no período")
            ->addData('Vendas', $salesByDate)
            ->setXAxis($dates);
    }
}
