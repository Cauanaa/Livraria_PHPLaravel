<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Fornecedores</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        input,
        select {
            margin-bottom: 18px;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup" style="justify-content: space-between;">
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="{{route('livros.index')}}">Livros</a>
                <a class="nav-item nav-link" href="{{route('funcionarios.index')}}">Funcionários</a>
                <a class="nav-item nav-link" href="{{route('vendas.index')}}">Vendas </a>
                <a class="nav-item nav-link" href="{{route('estoque.index')}}">Estoque </a>
                <a class="nav-item nav-link active" href="{{route('fornecedores.index')}}">Fornecedores </a>
            </div>
            <a class="nav-item nav-link active" href="{{route('logout')}}" style="color: rgba(255,255,255,.5); display: flex; align-items:center;gap: 8px;">LOGOUT<img src="/storage/sign-out.svg" /></a>
        </div>
    </nav>
    <div class="container" style="padding: 20px 0">
        <h2>Formulário de Fornecedores</h2>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
        @endif
        @php
        if (!empty($fornecedores->id)) {
        $route = route('fornecedores.update', $fornecedores->id);
        }
        else {
        $route = route('fornecedores.store');
        }
        @endphp

        <form action="{{$route}}" method="POST" enctype="multipart/form-data">
            @csrf
            @if (!empty($fornecedores->id))
            @method('PUT')
            @endif
            <input type="hidden" name="id" value="
            @if (!empty($fornecedores->id))
                    {{$fornecedores->id}}
                @elseif (!empty(old('id')))
                    {{old('id')}}
                @else
                    {{''}}
            @endif">
            <label for="">Nome</label>
            <input class="form-control" type="text" required name="nome" value="@if(!empty($fornecedores->nome)){{$fornecedores->nome}}@elseif(!empty(old('nome'))){{old('nome')}}@else{{''}}@endif">
            <label for="">CNPJ</label>
            <input class="form-control" type="text" required name="cnpj" value="@if(!empty($fornecedores->cnpj)){{$fornecedores->cnpj}}@elseif(!empty(old('cnpj'))){{old('cnpj')}}@else{{''}}@endif">
            <label for="">Endereço</label>
            <input class="form-control" type="text" required name="endereco" value="@if(!empty($fornecedores->endereco)){{$fornecedores->endereco}}@elseif(!empty(old('endereco'))){{old('endereco')}}@else{{''}}@endif">
            @php
            $nome_imagem = !empty($fornecedores->imagem) ? $fornecedores->imagem : 'sem_imagem.jpg';
            @endphp
            <div>
                <img class="h-40 w-40 object-cover rounded-full" src="/storage/{{ $nome_imagem }}" width="300px" alt="imagem">
                <br>
                <input type="file" name="imagem"><br>
            </div>
            <button type="submit" class="btn btn-success" style="height: 38px">Salvar</button>
            <a href="{{route('fornecedores.index')}}" class="btn btn-primary" style="height: 38px">Voltar</a>
        </form>
    </div>
    </div>

    <body>