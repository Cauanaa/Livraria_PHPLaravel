<?php

namespace App\Http\Controllers;

use App\Models\Fornecedores;
use Illuminate\Http\Request;

class FornecedoresController extends Controller
{
    /**
     * Carrega a listagem de dados
     */
    public function index()
    {
        $fornecedores = Fornecedores::all();

        return view('fornecedores.list')->with(['fornecedores'=> $fornecedores]);
    }

    /**
     * Carrega o formulário
     */
    public function create()
    {

        return view('fornecedores.form');
    }

    /**
     * Salva os dados do formulário
     */
    public function store(Request $request)
    {

        $request->validate([
            'nome'=>'max:100|required',
            'cnpj'=>'size:14|required',
            'endereco'=>'required'
        ],[
            'required'=>"O campo é obrigatório!",
            'max'=>" Só é permitido 100 caracteres no :attribute!",
            'size'=>"Só é permitido 14 caracteres no :attribute!",
        ]);

        $dados = ['nome'=> $request->nome,
            'cnpj'=> $request->cnpj,
            'endereco'=> $request->endereco,
        ];
        
        $imagem = $request->file('imagem');
        //verifica se existe imagem no formulário
    if($imagem){
        $nome_arquivo =
        date('YmdHis').'.'.$imagem->getClientOriginalExtension();

        $diretorio = "imagem/fornecedores/";
        //salva imagem em uma pasta do sistema
        $imagem->storeAs($diretorio,$nome_arquivo,'public');

        $dados['imagem'] = $diretorio.$nome_arquivo;
    }

        Fornecedores::create($dados); //ou  $request->all()

        return redirect('fornecedores')->with('success', "Cadastrado com sucesso!");
    }

    /**
     * Carrega apenas 1 registro da tabela
     */
    public function show(Fornecedores $aluno)
    {
        //
    }

    /**
     * Carrega o formulário para edição
     */
    public function edit($id)
    {
        $fornecedores = Fornecedores::find($id);


        return view('fornecedores.form')->with(['fornecedores'=>$fornecedores]);
    }

    /**
     * Atualiza os dados do formulário
     */
    public function update(Request $request, Fornecedores $fornecedores)
    {

        $request->validate([
            'nome'=>'max:100|required',
            'cnpj'=>'size:14|required',
            'endereco'=>'required'
        ],[
            'required'=>"O campo é obrigatório!",
            'max'=>" Só é permitido 100 caracteres no :attribute!",
            'size'=>"Só é permitido 14 caracteres no :attribute!",
        ]);

        $dados = ['nome'=> $request->nome,
            'cnpj'=> $request->cnpj,
            'endereco'=> $request->endereco,
        ];
        
        $imagem = $request->file('imagem');
        //verifica se existe imagem no formulário
    if($imagem){
        $nome_arquivo =
        date('YmdHis').'.'.$imagem->getClientOriginalExtension();

        $diretorio = "imagem/fornecedores/";
        //salva imagem em uma pasta do sistema
        $imagem->storeAs($diretorio,$nome_arquivo,'public');

        $dados['imagem'] = $diretorio.$nome_arquivo;
    }

        Fornecedores::updateOrCreate(
            ['id'=>$request->id],
            $dados);
 //ou  $request->all()

        return redirect('fornecedores')->with('success', "Cadastrado com sucesso!");
    }

    /**
     * Remove o registro do banco de dados
     */
    public function destroy($id)
    {
        $livro = Fornecedores::find($id);

        $livro->delete();

        return redirect('fornecedores')->with('success', "Removido com sucesso!");
    }
    public function search(Request $request)
    {
        if(!empty($request->valor)){
            $fornecedores = Fornecedores::where($request->tipo, 'like', "%". $request->valor."%")->get();
        } else{
            $fornecedores = Fornecedores::all();
        }
        return view('fornecedores.list')->with(['fornecedores'=> $fornecedores]);
    }

}
