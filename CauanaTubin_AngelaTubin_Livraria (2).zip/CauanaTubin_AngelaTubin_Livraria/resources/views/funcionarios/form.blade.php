<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Vendas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        input, select {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup" style="justify-content: space-between;">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="{{route('livros.index')}}">Livros</a>
      <a class="nav-item nav-link active" href="{{route('funcionarios.index')}}">Funcionários</a>
      <a class="nav-item nav-link" href="{{route('vendas.index')}}">Vendas </a>
      <a class="nav-item nav-link" href="{{route('estoque.index')}}">Estoque </a>
        <a class="nav-item nav-link" href="{{route('fornecedores.index')}}">Fornecedores </a>    
    </div>

    <a class="nav-item nav-link active" href="{{route('logout')}}" style="color: rgba(255,255,255,.5); display: flex; align-items:center;gap: 8px;">LOGOUT<img src="/storage/sign-out.svg" /></a>
 
    </div>
  </div>
</nav>
<div class="container" style="padding: 20px 0">
    <h2>Formulário de Funcionários</h2>
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
    @endif
    @php
        if (!empty($funcionarios->id)) {
            $route = route('funcionarios.update', $funcionarios->id);
        }
        else {
            $route = route('funcionarios.store');
        }
    @endphp
    <form action="{{$route}}" method="POST" enctype="multipart/form-data">
        @csrf
        @if (!empty($funcionarios->id))
             @method('PUT')
        @endif
        <input type="hidden" name="id" value="
            @if (!empty($funcionarios->id))
                    {{$funcionarios->id}}
                @elseif (!empty(old('id')))
                    {{old('id')}}
                @else
                    {{''}}
            @endif">
        <label for="">Nome</label>
        <input class="form-control" type="text" required name="nome" value="@if(!empty($funcionarios->nome)){{$funcionarios->nome}}@elseif(!empty(old('nome'))){{old('nome')}}@else{{''}}@endif">
        <label for="">Data de Admissão</label>
        <input class="form-control" type="date" required name="data_admissao" value="@if(!empty($funcionarios->data_admissao)){{str_replace(' 00:00:00','', $funcionarios->data_admissao)}}@elseif(!empty(old('data_admissao'))){{old('data_admissao')}}@else{{''}}@endif">
        <label for="">CPF</label>
        <input class="form-control" type="text" required name="cpf" value="@if(!empty($funcionarios->cpf)){{$funcionarios->cpf}}@elseif(!empty(old('cpf'))){{old('cpf')}}@else{{''}}@endif">
        <label for="">Email</label>
        <input class="form-control" type="text" required name="email" value="@if(!empty($funcionarios->email)){{$funcionarios->email}}@elseif(!empty(old('email'))){{old('email')}}@else{{''}}@endif">
        <button type="submit" class="btn btn-success" style="height: 38px">Salvar</button>
        <a href="{{route('funcionarios.index')}}" class="btn btn-primary" style="height: 38px">Voltar</a>
    </form>
    </div>
    </div>
    <body>
    