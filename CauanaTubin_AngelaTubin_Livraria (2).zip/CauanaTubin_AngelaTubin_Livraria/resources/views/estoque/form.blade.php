<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Estoque</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        input, select {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup" style="justify-content: space-between;">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="{{route('livros.index')}}">Livros</a>
      <a class="nav-item nav-link" href="{{route('funcionarios.index')}}">Funcionários</a>
      <a class="nav-item nav-link" href="{{route('vendas.index')}}">Vendas </a>
      <a class="nav-item nav-link active" href="{{route('estoque.index')}}">Estoque </a>
        <a class="nav-item nav-link" href="{{route('fornecedores.index')}}">Fornecedores </a>    
    </div>

    <a class="nav-item nav-link active" href="{{route('logout')}}" style="color: rgba(255,255,255,.5); display: flex; align-items:center;gap: 8px;">LOGOUT<img src="/storage/sign-out.svg" /></a>
 
    </div>
  </div>
</nav>
<div class="container" style="padding: 20px 0">
    <h2>Formulário de Estoque</h2>
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
    @endif
    @php
        // dd($estoque);
        // $route('estoque.store');
        if (!empty($estoque->id)) {
            $route = route('estoque.update', $estoque->id);
        }
        else {
            $route = route('estoque.store');
        }
    @endphp
   
    <form action="{{$route}}" method="POST" enctype="multipart/form-data">
        @csrf
        @if (!empty($estoque->id))
             @method('PUT')
        @endif
        
        <input type="hidden" name="id" value="
            @if (!empty($estoque->id))
                    {{$estoque->id}}
                @elseif (!empty(old('id')))
                    {{old('id')}}
                @else
                    {{''}}
            @endif"> <label for="">Livro</label>
        <select class="form-control" required name="livros_id">
            @foreach ($livros as $item )
                @if (!empty($estoque->livros_id) and $estoque->livros_id == $item->id)
                    <option value="{{$item->id}}" selected>{{$item->nome}}</option>
                @else
                    <option value="{{$item->id}}">{{$item->nome}}</option>
                @endif
            @endforeach
            
        </select>
            <label for="">Fornecedor</label>
        <select class="form-control" required name="fornecedores_id">
            @foreach ($fornecedores as $item )
                @if (!empty($estoque->fornecedores_id) and $estoque->fornecedores_id == $item->id)
                    <option value="{{$item->id}}" selected>{{$item->nome}}</option>
                @else
                    <option value="{{$item->id}}">{{$item->nome}}</option>
                @endif
            @endforeach
        </select>
        <label for="">Quantidade</label>
        <input class="form-control" type="number" required name="quantidade" value="@if(!empty($estoque->quantidade)){{$estoque->quantidade}}@elseif(!empty(old('quantidade'))){{old('quantidade')}}@else{{''}}@endif">
        <label for="">Motivo</label>
        <input class="form-control" type="text" required name="motivo" value="@if(!empty($estoque->motivo)){{$estoque->motivo}}@elseif(!empty(old('motivo'))){{old('motivo')}}@else{{''}}@endif">
        
        
        <button type="submit" class="btn btn-success" style="height: 38px">Salvar</button>
        <a href="{{route('estoque.index')}}" class="btn btn-primary" style="height: 38px">Voltar</a>
    </form>
    </div>
</body>
</html>
