<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Livros</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        input, select {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link active" href="<?php echo e(route('livros.index')); ?>">Livros</a>
      <a class="nav-item nav-link" href="<?php echo e(route('funcionarios.index')); ?>">Funcionários</a>
      <a class="nav-item nav-link" href="<?php echo e(route('vendas.index')); ?>">Vendas </a>
      <a class="nav-item nav-link" href="<?php echo e(route('estoque.index')); ?>">Estoque </a>
      <a class="nav-item nav-link" href="<?php echo e(route('fornecedores.index')); ?>">Fornecedores </a>
    </div>
  </div>
</nav>
<div class="container" style="padding: 20px 0">
    <h2>Formulário de Livros</h2>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php
        // dd($livros);
        // $route('livros.store');
        if (!empty($livros->id)) {
            $route = route('livros.update', $livros->id);
        }
        else {
            $route = route('livros.store');
        }
    ?>
    <form action="<?php echo e($route); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(!empty($livros->id)): ?>
             <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <input type="hidden" name="id" value="
            <?php if(!empty($livros->id)): ?>
                    <?php echo e($livros->id); ?>

                <?php elseif(!empty(old('id'))): ?>
                    <?php echo e(old('id')); ?>

                <?php else: ?>
                    <?php echo e(''); ?>

            <?php endif; ?>">

        <label for="">Nome</label><br>
        <input class="form-control" type="text" required name="nome" value="<?php if(!empty($livros->nome)): ?><?php echo e($livros->nome); ?><?php elseif(!empty(old('nome'))): ?><?php echo e(old('nome')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        <label for="">Editora</label><br>
        <input class="form-control" type="text" required name="editora" value="<?php if(!empty($livros->editora)): ?><?php echo e($livros->editora); ?><?php elseif(!empty(old('editora'))): ?><?php echo e(old('editora')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        <label for="">Ano de Publicação</label><br>
        <input class="form-control" type="number" required name="ano_publi" value="<?php if(!empty($livros->ano_publi)): ?><?php echo e(str_replace(' 00:00:00','', $livros->ano_publi)); ?><?php elseif(!empty(old('ano_publi'))): ?><?php echo e(old('ano_publi')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        <label for="">Autor</label><br>
        <input class="form-control" type="text" required name="autor" value="<?php if(!empty($livros->autor)): ?><?php echo e($livros->autor); ?><?php elseif(!empty(old('autor'))): ?><?php echo e(old('autor')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        <label for="">Preço</label><br>
        <input class="form-control" type="number" required name="preco" step='0.01' value="<?php if(!empty($livros->preco)): ?><?php echo e($livros->preco); ?><?php elseif(!empty(old('preco'))): ?><?php echo e(old('preco')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        <?php
                $nome_imagem = !empty($livros->imagem) ? $livros->imagem : 'sem_imagem.jpg';
                                    $splittedArray = explode("/", $_SERVER['REQUEST_URI']);
                                    $splittedArray = array_slice($splittedArray,0, 3);
                                    $url = join("/", $splittedArray);
                                    
                                ?>
                <div>
                    <img class="h-40 w-40 object-cover rounded-full" src="<?php echo e($url); ?>/storage/<?php echo e($nome_imagem); ?>" width="300px"
                        alt="imagem">
                    <br>
                    <input
                        class="block w-full text-sm text-slate-500
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-full file:border-0
                                file:text-sm file:font-semibold
                                file:bg-green-50 file:text-green-700
                                hover:file:bg-green-100"
                        type="file" name="imagem"><br>
                </div>
        <button type="submit" class="btn btn-success" style="height: 38px">Salvar</button>
        <a href="<?php echo e(route('livros.index')); ?>" class="btn btn-primary" style="height: 38px">Voltar</a>
    </form>
</body>
</html>

<?php /**PATH C:\laragon\www\juliusAmazingLovingGodMajesticWonderfulHandsome\resources\views/livros/form.blade.php ENDPATH**/ ?>