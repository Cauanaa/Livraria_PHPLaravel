<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Relatório Estoque</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-2">
        <h2 class="text-center mb-2"><?php echo e($title); ?></h2>
        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-success">
                <th scope="col">ID</th>
                <th scope="col">Livro</th>
                <th scope="col">Fornecedor</th>
                <th scope="col">Quantidade</th>
                <th scope="col">Motivo</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $estoque ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->livro->nome ?? ""); ?></td>
                <td><?php echo e($item->fornecedor->nome ?? ""); ?></td>
                <td><?php echo e($item->quantidade); ?></td>
                <td><?php echo e($item->motivo); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\Livraria\resources\views/estoque/report.blade.php ENDPATH**/ ?>