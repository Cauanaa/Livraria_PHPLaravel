<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Relatório Funcionários</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-2">
        <h2 class="text-center mb-2"><?php echo e($title); ?></h2>
        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-success">
                    <th scope="col">ID</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Data de Admissão</th>
                    <th scope="col">CPF</th>
                    <th scope="col">Email</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $funcionarios ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $date = date_create($item->data_admissao);
                    $formattedDate = date_format($date,"d/m/Y");
                ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->nome); ?></td>
                    <td><?php echo e($formattedDate); ?></td>
                    <td><?php echo e($item->cpf); ?></td>
                    <td><?php echo e($item->email); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\juliusAmazingLovingGodMajesticWonderfulHandsome\resources\views/funcionarios/report.blade.php ENDPATH**/ ?>