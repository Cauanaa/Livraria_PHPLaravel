<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vendas extends Model
{
    use HasFactory;
    protected $table = "vendas";

    protected $fillable = ['nome',
        'livros_id',
        'funcionarios_id',
        'data'
    ];

    protected $casts = [
        'data'=>"date",
        'funcionarios_id'=>"integer",
        'livros_id'=>"integer",
    ];

    public function funcionario(){
        return $this->belongsTo(Funcionarios::class,
            'funcionarios_id','id');
    }

    public function livro(){
        return $this->belongsTo(Livros::class,
            'livros_id','id');
    }
}
