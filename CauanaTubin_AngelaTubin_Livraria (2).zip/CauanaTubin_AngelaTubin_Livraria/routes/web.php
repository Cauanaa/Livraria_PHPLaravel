<?php

use Illuminate\Support\Facades\Route;
//importar o arquivo do controlador
// use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\LivrosController;
use App\Http\Controllers\FuncionariosController;
use App\Http\Controllers\VendasController;
use App\Http\Controllers\FornecedoresController;
use App\Http\Controllers\EstoqueController;

Route::get('/', function () {
    return view('welcome');
});

Route::middleware('auth')->group(function () {
//chamar uma função do controlador
// Route::get('/usuario', [UsuarioController::class, 'index']);

//rota livros
Route::get('/livros',
 [LivrosController::class, 'index'])->name('livros.index');

Route::get('/livros/create',
 [LivrosController::class, 'create'])->name('livros.create');

 Route::post('/livros',
[LivrosController::class, 'store'])->name('livros.store');

Route::get('/livros/edit/{id}',
 [LivrosController::class, 'edit'])->name('livros.edit');

 Route::put('/livros/update/{id}',
[LivrosController::class, 'update'])->name('livros.update');

Route::get('/livros/destroy/{id}',
 [LivrosController::class, 'destroy'])->name('livros.destroy');

 Route::post('/livros/search',
[LivrosController::class, 'search'])->name('livros.search');

//chamar uma página em HTML
Route::get('/pagina', function () {
    return view('index');
});

//chama um HTML
Route::get('/teste', function () {
    return "<h4>Olá Mundo Laravel!</h4>";
});


//rota funcionarios
Route::get('/funcionarios',
 [FuncionariosController::class, 'index'])->name('funcionarios.index');

Route::get('/funcionarios/create',
 [FuncionariosController::class, 'create'])->name('funcionarios.create');

 Route::post('/funcionarios',
[FuncionariosController::class, 'store'])->name('funcionarios.store');

Route::get('/funcionarios/edit/{id}',
 [FuncionariosController::class, 'edit'])->name('funcionarios.edit');

 Route::put('/funcionarios/update/{id}',
[FuncionariosController::class, 'update'])->name('funcionarios.update');

Route::get('/funcionarios/destroy/{id}',
 [FuncionariosController::class, 'destroy'])->name('funcionarios.destroy');

 Route::post('/funcionarios/search',
[FuncionariosController::class, 'search'])->name('funcionarios.search');

//rota vendas
Route::get('/vendas',
 [VendasController::class, 'index'])->name('vendas.index');

Route::get('/vendas/create',
 [VendasController::class, 'create'])->name('vendas.create');

 Route::post('/vendas',
[VendasController::class, 'store'])->name('vendas.store');

Route::get('/vendas/edit/{id}',
 [VendasController::class, 'edit'])->name('vendas.edit');

 Route::put('/vendas/update/{id}',
[VendasController::class, 'update'])->name('vendas.update');

Route::get('/vendas/destroy/{id}',
 [VendasController::class, 'destroy'])->name('vendas.destroy');

 Route::post('/vendas/search',
[VendasController::class, 'search'])->name('vendas.search');

//rota fornecedores
Route::get('/fornecedores',
 [FornecedoresController::class, 'index'])->name('fornecedores.index');

Route::get('/fornecedores/create',
 [FornecedoresController::class, 'create'])->name('fornecedores.create');

 Route::post('/fornecedores',
[FornecedoresController::class, 'store'])->name('fornecedores.store');

Route::get('/fornecedores/edit/{id}',
 [FornecedoresController::class, 'edit'])->name('fornecedores.edit');

 Route::put('/fornecedores/update/{id}',
[FornecedoresController::class, 'update'])->name('fornecedores.update');

Route::get('/fornecedores/destroy/{id}',
 [FornecedoresController::class, 'destroy'])->name('fornecedores.destroy');

 Route::post('/fornecedores/search',
[FornecedoresController::class, 'search'])->name('fornecedores.search');

//rota estoque
Route::get('/estoque',
 [EstoqueController::class, 'index'])->name('estoque.index');

Route::get('/estoque/create',
 [EstoqueController::class, 'create'])->name('estoque.create');

 Route::post('/estoque',
[EstoqueController::class, 'store'])->name('estoque.store');

Route::get('/estoque/edit/{id}',
 [EstoqueController::class, 'edit'])->name('estoque.edit');

 Route::put('/estoque/update/{id}',
[EstoqueController::class, 'update'])->name('estoque.update');

Route::get('/estoque/destroy/{id}',
 [EstoqueController::class, 'destroy'])->name('estoque.destroy');

 Route::post('/estoque/search',
[EstoqueController::class, 'search'])->name('estoque.search');

Route::get('/estoque/chart/',
 [EstoqueController::class, 'chart'])->name('estoque.chart');
});

Route::get('/vendas/chart/',
 [VendasController::class, 'chart'])->name('vendas.chart');

 //relatorio
 Route::get('/estoque/report/',
 [EstoqueController::class, 'report'])->name('estoque.report');

 Route::get('/funcionarios/report/',
 [FuncionariosController::class, 'report'])->name('funcionarios.report');

require __DIR__.'/auth.php';